
import SwiftUI
// ================================
// App entry point (único @main)
// ================================
@main
struct ProyectoIOSApp: App {
    var body: some Scene {
        WindowGroup {
            LoginView()
        }
    }
}
// ================================
// Modelos de datos
// ================================
struct Usuario: Identifiable {
    let id = UUID()
    let correo: String
    let contrasena: String
    let nombre: String
}
struct Accion {
    let nombre: String
    let porcentaje: Double
    let color: Color
}
struct AccionMercado: Identifiable {
    let id = UUID()
    let nombre: String
    let precio: Double
    let cambio: Double
}
struct Transaccion: Identifiable {
    let id = UUID()
    let descripcion: String
    let fecha: Date
}
// ================================
// Login con navegación a registro
// ================================
struct LoginView: View {
    @State private var correo = ""
    @State private var contrasena = ""
    @State private var mostrarPrincipal = false
    @State private var mensajeError = ""
    
    // Arreglo mutable de usuarios
    @State private var usuarios: [Usuario] = [
        Usuario(correo: "al02976904tecmilenio.mx", contrasena: "Tecmilenio#06", nombre: "Mauricio Estrada De la Garza"),
        Usuario(correo: "al03091719@tecmilenio.mx", contrasena: "1234567890", nombre: "Brayan Eleazar Villegas Navarro"),
        Usuario(correo: "al02665142@tecmilenio.mx", contrasena: "0987654321", nombre: "Hugo Adrian Casas Elizondo")
    ]
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Text("Inicio de Sesión")
                    .font(.largeTitle)
                    .bold()
                
                TextField("Correo", text: $correo)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .autocapitalization(.none)
                    .keyboardType(.emailAddress)
                
                SecureField("Contraseña", text: $contrasena)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Button("Iniciar Sesión") {
                    if let usuario = usuarios.first(where: { $0.correo == correo && $0.contrasena == contrasena }) {
                        UserDefaults.standard.set(usuario.nombre, forKey: "nombreUsuario")
                        mostrarPrincipal = true
                        mensajeError = ""
                    } else {
                        mensajeError = "Correo o contraseña incorrectos"
                    }
                }
                .buttonStyle(.borderedProminent)
                .tint(.green)
                
                if !mensajeError.isEmpty {
                    Text(mensajeError)
                        .foregroundColor(.red)
                        .bold()
                }
                
                NavigationLink(destination: ContentView(), isActive: $mostrarPrincipal) {
                    EmptyView()
                }
                
                // Botón a pantalla de registro
                NavigationLink(destination: RegistroView(usuarios: $usuarios)) {
                    Text("Registrar usuario")
                        .foregroundColor(.blue)
                        .underline()
                }
            }
            .padding()
        }
    }
}
// ================================
// Registro de usuario
// ================================
struct RegistroView: View {
    @Binding var usuarios: [Usuario]
    @State private var correo = ""
    @State private var contrasena = ""
    @State private var nombre = ""
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Registrar nuevo usuario")
                .font(.title)
                .bold()
            
            TextField("Nombre", text: $nombre)
                .textFieldStyle(RoundedBorderTextFieldStyle())
            
            TextField("Correo", text: $correo)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .autocapitalization(.none)
                .keyboardType(.emailAddress)
            
            SecureField("Contraseña", text: $contrasena)
                .textFieldStyle(RoundedBorderTextFieldStyle())
            
            Button("Guardar usuario") {
                guard !correo.isEmpty, !contrasena.isEmpty, !nombre.isEmpty else { return }
                // Evitar duplicados por correo
                if !usuarios.contains(where: { $0.correo.lowercased() == correo.lowercased() }) {
                    let nuevoUsuario = Usuario(correo: correo, contrasena: contrasena, nombre: nombre)
                    usuarios.append(nuevoUsuario)
                }
                presentationMode.wrappedValue.dismiss()
            }
            .buttonStyle(.borderedProminent)
            .tint(.green)
        }
        .padding()
    }
}
// ================================
// Menú principal
// ================================
struct ContentView: View {
    @State private var selectedScreen: String? = "Inicio"
    
    var body: some View {
        NavigationView {
            List(selection: $selectedScreen) {
                NavigationLink(destination: InicioView(), tag: "Inicio", selection: $selectedScreen) {
                    Label("Inicio", systemImage: "house.fill")
                }
                NavigationLink(destination: PortafolioView(), tag: "Portafolio", selection: $selectedScreen) {
                    Label("Portafolio", systemImage: "briefcase.fill")
                }
                NavigationLink(destination: InvertirView(), tag: "Invertir", selection: $selectedScreen) {
                    Label("Invertir", systemImage: "chart.bar.fill")
                }
                NavigationLink(destination: TransaccionesView(), tag: "Transacciones", selection: $selectedScreen) {
                    Label("Transacciones", systemImage: "arrow.2.squarepath")
                }
                NavigationLink(destination: ConfiguracionView(), tag: "Configuración", selection: $selectedScreen) {
                    Label("Configuración", systemImage: "gear")
                }
            }
            .listStyle(SidebarListStyle())
            .navigationTitle("Opciones")
            
            InicioView()
        }
    }
}
// ================================
// Pantalla de inicio
// ================================
struct InicioView: View {
    var nombreUsuario: String {
        UserDefaults.standard.string(forKey: "nombreUsuario") ?? "Usuario"
    }
    
    var body: some View {
        ZStack {
            Color.green.ignoresSafeArea()
            Text("BIENVENIDO \(nombreUsuario.uppercased())!")
                .font(.title)
                .foregroundColor(.white)
                .bold()
        }
    }
}
// ================================
// Portafolio con Pie Chart
// ================================
struct PortafolioView: View {
    let acciones: [Accion] = [
        Accion(nombre: "Microsoft", porcentaje: 20, color: .blue),
        Accion(nombre: "Google", porcentaje: 15, color: .red),
        Accion(nombre: "Facebook", porcentaje: 10, color: .purple),
        Accion(nombre: "Coca Cola", porcentaje: 25, color: .green),
        Accion(nombre: "McDonalds", porcentaje: 10, color: .orange),
        Accion(nombre: "Apple", porcentaje: 20, color: .pink)
    ]
    
    let rendimiento: Double = 5.4
    let montoTotal: Double = 10000
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                Text("Portafolio de Acciones")
                    .font(.title)
                    .bold()
                
                PieChartView(acciones: acciones)
                    .frame(width: 300, height: 300)
                
                HStack {
                    Image(systemName: rendimiento >= 0 ? "arrow.up" : "arrow.down")
                        .foregroundColor(rendimiento >= 0 ? .green : .red)
                    Text(String(format: "%.2f%%", rendimiento))
                        .font(.title2)
                        .foregroundColor(rendimiento >= 0 ? .green : .red)
                    Text("de rendimiento")
                        .foregroundColor(.gray)
                }
                
                Text("Total invertido: $\(String(format: "%.2f", montoTotal))")
                    .font(.headline)
            }
            .padding()
        }
    }
}
// ================================
// Pie chart components
// ================================
struct PieSliceData: Hashable {
    let index: Int
    let startAngle: Angle
    let endAngle: Angle
    let color: Color
}
struct PieSlice: Shape {
    let startAngle: Angle
    let endAngle: Angle
    
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let center = CGPoint(x: rect.midX, y: rect.midY)
        let radius = min(rect.width, rect.height) / 2
        
        path.move(to: center)
        path.addArc(center: center,
                    radius: radius,
                    startAngle: startAngle - Angle(degrees: 90),
                    endAngle: endAngle - Angle(degrees: 90),
                    clockwise: false)
        path.closeSubpath()
        return path
    }
}
struct PieChartView: View {
    let acciones: [Accion]
    
    var body: some View {
        GeometryReader { geometry in
            let size = min(geometry.size.width, geometry.size.height)
            
            ZStack {
                ForEach(slices(), id: \.self.index) { slice in
                    ZStack {
                        PieSlice(startAngle: slice.startAngle, endAngle: slice.endAngle)
                            .fill(slice.color)
                        
                        let midAngle = (slice.startAngle.degrees + slice.endAngle.degrees) / 2
                        let radius = size * 0.35
                        let center = CGPoint(x: size / 2, y: size / 2)
                        let x = center.x + radius * cos(CGFloat(midAngle - 90) * .pi / 180)
                        let y = center.y + radius * sin(CGFloat(midAngle - 90) * .pi / 180)
                        
                        Text("\(acciones[slice.index].nombre)\n\(acciones[slice.index].porcentaje, specifier: "%.0f")%")
                            .font(.caption2)
                            .multilineTextAlignment(.center)
                            .padding(4)
                            .background(Color.black.opacity(0.5))
                            .cornerRadius(5)
                            .foregroundColor(.white)
                            .position(x: x, y: y)
                    }
                }
                
                Circle()
                    .fill(Color.white)
                    .frame(width: size * 0.5, height: size * 0.5)
                
                VStack {
                    Text("Portafolio")
                        .font(.caption)
                        .foregroundColor(.gray)
                }
            }
            .frame(width: size, height: size)
        }
    }
    
    func slices() -> [PieSliceData] {
        var slices: [PieSliceData] = []
        let total = acciones.reduce(0) { $0 + $1.porcentaje }
        var startAngle = Angle(degrees: 0)
        
        for (index, accion) in acciones.enumerated() {
            let angle = Angle(degrees: (accion.porcentaje / total) * 360)
            let endAngle = startAngle + angle
            slices.append(PieSliceData(index: index, startAngle: startAngle, endAngle: endAngle, color: accion.color))
            startAngle = endAngle
        }
        return slices
    }
}
// ================================
// Pantalla invertir
// ================================
struct InvertirView: View {
    @State private var searchText = ""
    
    let mercadoAcciones: [AccionMercado] = [
        AccionMercado(nombre: "Tesla", precio: 250.30, cambio: 3.2),
        AccionMercado(nombre: "Amazon", precio: 135.80, cambio: -1.5),
        AccionMercado(nombre: "Netflix", precio: 420.10, cambio: 0.8),
        AccionMercado(nombre: "Apple", precio: 180.40, cambio: -0.6),
        AccionMercado(nombre: "Microsoft", precio: 310.25, cambio: 2.1)
    ]
    
    var filteredAcciones: [AccionMercado] {
        if searchText.isEmpty {
            return mercadoAcciones
        } else {
            return mercadoAcciones.filter { $0.nombre.lowercased().contains(searchText.lowercased()) }
        }
    }
    
    var body: some View {
        VStack {
            TextField("Buscar acción...", text: $searchText)
                .padding(10)
                .background(Color(.systemGray6))
                .cornerRadius(8)
                .padding()
            
            List(filteredAcciones) { accion in
                HStack {
                    VStack(alignment: .leading) {
                        Text(accion.nombre)
                            .font(.headline)
                        Text(String(format: "$%.2f", accion.precio))
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                    Spacer()
                    HStack {
                        Image(systemName: accion.cambio >= 0 ? "arrow.up" : "arrow.down")
                            .foregroundColor(accion.cambio >= 0 ? .green : .red)
                        Text(String(format: "%.2f%%", accion.cambio))
                            .foregroundColor(accion.cambio >= 0 ? .green : .red)
                            .font(.subheadline)
                    }
                }
            }
        }
        .navigationTitle("Invertir")
    }
}
// ================================
// Pantalla transacciones
// ================================
struct TransaccionesView: View {
    @State private var transacciones: [Transaccion] = [
        Transaccion(descripcion: "Compra Apple x10", fecha: Date().addingTimeInterval(-3600 * 24 * 2)),
        Transaccion(descripcion: "Venta Tesla x5", fecha: Date().addingTimeInterval(-3600 * 24 * 5)),
        Transaccion(descripcion: "Compra Microsoft x8", fecha: Date().addingTimeInterval(-3600 * 24 * 10))
    ]
    
    var body: some View {
        List(transacciones) { t in
            VStack(alignment: .leading, spacing: 4) {
                Text(t.descripcion)
                    .font(.headline)
                Text(formatearFecha(t.fecha))
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
        .navigationTitle("Transacciones")
    }
    
    private func formatearFecha(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
}
// ================================
// Pantalla configuración
// ================================
struct ConfiguracionView: View {
    @State private var notificaciones = true
    @State private var temaOscuro = false
    
    var body: some View {
        Form {
            Toggle("Notificaciones", isOn: $notificaciones)
            Toggle("Tema oscuro", isOn: $temaOscuro)
            Section(header: Text("Cuenta")) {
                Button(role: .destructive) {
                    // Limpia nombre guardado
                    UserDefaults.standard.removeObject(forKey: "nombreUsuario")
                } label: {
                    Text("Cerrar sesión (limpiar nombre)")
                }
            }
        }
        .navigationTitle("Configuración")
    }
}

