import SwiftUI

// Datos de acciones para el portafolio
struct Accion {
    let nombre: String
    let porcentaje: Double
    let color: Color
}

// Datos de acciones para la pantalla Invertir
struct AccionMercado: Identifiable {
    let id = UUID()
    let nombre: String
    let precio: Double
    let cambio: Double // positivo o negativo
}

// Datos de transacciones
struct Transaccion: Identifiable {
    let id = UUID()
    let descripcion: String
    let fecha: Date
}

// Vista principal con navegación
struct ContentView: View {
    @State private var selectedScreen: String? = "Inicio"

    var body: some View {
        NavigationView {
            List(selection: $selectedScreen) {
                NavigationLink(destination: InicioView(), tag: "Inicio", selection: $selectedScreen) {
                    Label("Inicio", systemImage: "house.fill")
                }
                NavigationLink(destination: PortafolioView(), tag: "Portafolio", selection: $selectedScreen) {
                    Label("Portafolio", systemImage: "briefcase.fill")
                }
                NavigationLink(destination: InvertirView(), tag: "Invertir", selection: $selectedScreen) {
                    Label("Invertir", systemImage: "chart.bar.fill")
                }
                NavigationLink(destination: TransaccionesView(), tag: "Transacciones", selection: $selectedScreen) {
                    Label("Transacciones", systemImage: "arrow.2.squarepath")
                }
                NavigationLink(destination: ConfiguracionView(), tag: "Configuración", selection: $selectedScreen) {
                    Label("Configuración", systemImage: "gear")
                }
            }
            .listStyle(SidebarListStyle())
            .navigationTitle("Opciones")

            InicioView()
        }
    }
}

// Vista de bienvenida
struct InicioView: View {
    var body: some View {
        ZStack {
            Color.green.ignoresSafeArea()
            Text("BIENVENIDO MAURICIO ESTRADA!")
                .font(.title)
                .foregroundColor(.white)
                .bold()
        }
    }
}

// Vista del Portafolio con gráfica de pastel
struct PortafolioView: View {
    let acciones: [Accion] = [
        Accion(nombre: "Microsoft", porcentaje: 20, color: .blue),
        Accion(nombre: "Google", porcentaje: 15, color: .red),
        Accion(nombre: "Facebook", porcentaje: 10, color: .purple),
        Accion(nombre: "Coca Cola", porcentaje: 25, color: .green),
        Accion(nombre: "McDonalds", porcentaje: 10, color: .orange),
        Accion(nombre: "Apple", porcentaje: 20, color: .pink)
    ]

    let rendimiento: Double = 5.4
    let montoTotal: Double = 10000

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                Text("Portafolio de Acciones")
                    .font(.title)
                    .bold()

                PieChartView(acciones: acciones)
                    .frame(width: 300, height: 300)

                // Rendimiento
                HStack {
                    Image(systemName: rendimiento >= 0 ? "arrow.up" : "arrow.down")
                        .foregroundColor(rendimiento >= 0 ? .green : .red)
                    Text(String(format: "%.2f%%", rendimiento))
                        .font(.title2)
                        .foregroundColor(rendimiento >= 0 ? .green : .red)
                    Text("de rendimiento")
                        .foregroundColor(.gray)
                }

                // Monto total
                Text("Total invertido: $\(String(format: "%.2f", montoTotal))")
                    .font(.headline)
            }
            .padding()
        }
    }
}

// Vista de la gráfica de pastel
struct PieChartView: View {
    let acciones: [Accion]

    var body: some View {
        GeometryReader { geometry in
            let size = min(geometry.size.width, geometry.size.height)

            ZStack {
                ForEach(slices(), id: \.self.index) { slice in
                    ZStack {
                        PieSlice(startAngle: slice.startAngle, endAngle: slice.endAngle)
                            .fill(slice.color)

                        let midAngle = (slice.startAngle.degrees + slice.endAngle.degrees) / 2
                        let radius = size * 0.35
                        let center = CGPoint(x: size / 2, y: size / 2)
                        let x = center.x + radius * cos(CGFloat(midAngle - 90) * .pi / 180)
                        let y = center.y + radius * sin(CGFloat(midAngle - 90) * .pi / 180)

                        Text("\(acciones[slice.index].nombre)\n\(acciones[slice.index].porcentaje, specifier: "%.0f")%")
                            .font(.caption2)
                            .multilineTextAlignment(.center)
                            .padding(4)
                            .background(Color.black.opacity(0.5))
                            .cornerRadius(5)
                            .foregroundColor(.white)
                            .position(x: x, y: y)
                    }
                }

                Circle()
                    .fill(Color.white)
                    .frame(width: size * 0.5, height: size * 0.5)

                VStack {
                    Text("Portafolio")
                        .font(.caption)
                        .foregroundColor(.gray)
                }
            }
            .frame(width: size, height: size)
        }
    }

    func slices() -> [PieSliceData] {
        var slices: [PieSliceData] = []
        let total = acciones.reduce(0) { $0 + $1.porcentaje }
        var startAngle = Angle(degrees: 0)

        for (index, accion) in acciones.enumerated() {
            let angle = Angle(degrees: (accion.porcentaje / total) * 360)
            let endAngle = startAngle + angle
            slices.append(PieSliceData(index: index, startAngle: startAngle, endAngle: endAngle, color: accion.color))
            startAngle = endAngle
        }

        return slices
    }
}

// Pantalla Invertir
struct InvertirView: View {
    @State private var searchText = ""

    let mercadoAcciones: [AccionMercado] = [
        AccionMercado(nombre: "Tesla", precio: 250.30, cambio: 3.2),
        AccionMercado(nombre: "Amazon", precio: 135.80, cambio: -1.5),
        AccionMercado(nombre: "Netflix", precio: 420.10, cambio: 0.8),
        AccionMercado(nombre: "Apple", precio: 180.40, cambio: -0.6),
        AccionMercado(nombre: "Microsoft", precio: 310.25, cambio: 2.1)
    ]

    var filteredAcciones: [AccionMercado] {
        if searchText.isEmpty {
            return mercadoAcciones
        } else {
            return mercadoAcciones.filter { $0.nombre.lowercased().contains(searchText.lowercased()) }
        }
    }

    var body: some View {
        VStack {
            TextField("Buscar acción...", text: $searchText)
                .padding(10)
                .background(Color(.systemGray6))
                .cornerRadius(8)
                .padding()

            List(filteredAcciones) { accion in
                HStack {
                    Text(accion.nombre)
                        .font(.headline)

                    Spacer()

                    Text("$\(accion.precio, specifier: "%.2f")")
                        .font(.subheadline)

                    HStack {
                        Image(systemName: accion.cambio >= 0 ? "arrow.up" : "arrow.down")
                            .foregroundColor(accion.cambio >= 0 ? .green : .red)
                        Text("\(accion.cambio, specifier: "%.1f")%")
                            .foregroundColor(accion.cambio >= 0 ? .green : .red)
                            .font(.subheadline)
                    }
                    .padding(.leading, 5)
                }
                .padding(.vertical, 4)
            }
        }
        .navigationTitle("Invertir")
    }
}

// Pantalla Transacciones
struct TransaccionesView: View {
    let transacciones: [Transaccion] = [
        Transaccion(descripcion: "Se ha depositado $10,000 pesos a la cuenta", fecha: Date())
    ]

    var body: some View {
        List(transacciones) { transaccion in
            VStack(alignment: .leading, spacing: 5) {
                Text(transaccion.descripcion)
                    .font(.body)
                Text(transaccion.fecha, style: .date)
                    .font(.caption)
                    .foregroundColor(.gray)
            }
            .padding(.vertical, 4)
        }
        .navigationTitle("Transacciones")
    }
}

// Pantalla Configuración
struct ConfiguracionView: View {
    var body: some View {
        Form {
            Section(header: Text("Datos Personales")) {
                NavigationLink("Perfil", destination: Text("Editar perfil"))
                NavigationLink("Dirección", destination: Text("Editar dirección"))
            }

            Section(header: Text("Cuentas Bancarias")) {
                NavigationLink("Tarjetas vinculadas", destination: Text("Administrar tarjetas"))
                NavigationLink("Cuentas CLABE", destination: Text("Administrar cuentas"))
            }

            Section(header: Text("Seguridad")) {
                NavigationLink("Métodos de Autenticación", destination: Text("Configurar autenticación"))
                NavigationLink("Cambiar contraseña", destination: Text("Actualizar contraseña"))
            }

            Section(header: Text("Notificaciones")) {
                Toggle("Notificaciones push", isOn: .constant(true))
                Toggle("Alertas por correo", isOn: .constant(false))
            }

            Section(header: Text("Preferencias")) {
                NavigationLink("Idioma", destination: Text("Seleccionar idioma"))
                NavigationLink("Tema", destination: Text("Claro / Oscuro"))
            }
        }
        .navigationTitle("Configuración")
    }
}

// PieSlice Shape
struct PieSlice: Shape {
    var startAngle: Angle
    var endAngle: Angle

    func path(in rect: CGRect) -> Path {
        var path = Path()
        let center = CGPoint(x: rect.midX, y: rect.midY)
        path.move(to: center)

        path.addArc(center: center,
                    radius: min(rect.width, rect.height) / 2,
                    startAngle: startAngle - Angle(degrees: 90),
                    endAngle: endAngle - Angle(degrees: 90),
                    clockwise: false)

        path.closeSubpath()
        return path
    }
}

// Estructura auxiliar para cada segmento
struct PieSliceData: Hashable {
    let index: Int
    let startAngle: Angle
    let endAngle: Angle
    let color: Color
}

// Vista previa
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

