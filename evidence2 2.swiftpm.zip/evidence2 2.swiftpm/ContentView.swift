import SwiftUI

// ================================
// App entry point (único @main)
// ================================
@main
struct ProyectoIOSApp: App {
    @StateObject private var appState = AppState()
    var body: some Scene {
        WindowGroup {
            LoginView()
                .environmentObject(appState)
        }
    }
}

// ================================
// MODELOS Y ESTADO GLOBAL
// ================================
class AppState: ObservableObject {
    @Published var usuarios: [Usuario] = []

    init() {
        // colores para las acciones
        let colores: [Color] = [.blue, .green, .red, .orange, .purple, .pink, .yellow, .cyan]

        // Usuarios iniciales con 6 acciones distintas cada uno
        let accionesMauricio = [
            Accion(nombre: "Apple", porcentaje: 20, color: colores[0]),
            Accion(nombre: "Microsoft", porcentaje: 18, color: colores[1]),
            Accion(nombre: "Coca-Cola", porcentaje: 12, color: colores[2]),
            Accion(nombre: "Nike", porcentaje: 10, color: colores[3]),
            Accion(nombre: "Visa", porcentaje: 20, color: colores[4]),
            Accion(nombre: "Disney", porcentaje: 20, color: colores[5])
        ]

        let accionesBrayan = [
            Accion(nombre: "Amazon", porcentaje: 22, color: colores[1]),
            Accion(nombre: "Chevron", porcentaje: 16, color: colores[2]),
            Accion(nombre: "Intel", porcentaje: 12, color: colores[3]),
            Accion(nombre: "McDonald’s", porcentaje: 15, color: colores[4]),
            Accion(nombre: "Goldman Sachs", porcentaje: 18, color: colores[5]),
            Accion(nombre: "Boeing", porcentaje: 17, color: colores[6])
        ]

        let accionesHugo = [
            Accion(nombre: "IBM", porcentaje: 16, color: colores[2]),
            Accion(nombre: "Johnson & Johnson", porcentaje: 18, color: colores[3]),
            Accion(nombre: "Procter & Gamble", porcentaje: 16, color: colores[4]),
            Accion(nombre: "Home Depot", porcentaje: 20, color: colores[5]),
            Accion(nombre: "3M", porcentaje: 15, color: colores[6]),
            Accion(nombre: "Merck", porcentaje: 15, color: colores[7])
        ]

        usuarios = [
            Usuario(correo: "al02976904tecmilenio.mx", contrasena: "Tecmilenio#06", nombre: "Mauricio Estrada De la Garza", acciones: accionesMauricio, transacciones: [
                Transaccion(descripcion: "Compra Apple x10", fecha: Date().addingTimeInterval(-3600*24*10)),
                Transaccion(descripcion: "Compra Microsoft x5", fecha: Date().addingTimeInterval(-3600*24*8)),
            ]),
            Usuario(correo: "al03091719@tecmilenio.mx", contrasena: "1234567890", nombre: "Brayan Eleazar Villegas Navarro", acciones: accionesBrayan, transacciones: [
                Transaccion(descripcion: "Compra Amazon x2", fecha: Date().addingTimeInterval(-3600*24*6))
            ]),
            Usuario(correo: "al02665142@tecmilenio.mx", contrasena: "0987654321", nombre: "Hugo Adrian Casas Elizondo", acciones: accionesHugo, transacciones: [])
        ]
    }

    // helper: buscar índice de usuario activo por correo o nombre
    func indexUsuarioActivo() -> Int? {
        if let correo = UserDefaults.standard.string(forKey: "correoActivo") {
            return usuarios.firstIndex(where: { $0.correo == correo })
        }
        if let nombre = UserDefaults.standard.string(forKey: "nombreUsuario") {
            return usuarios.firstIndex(where: { $0.nombre == nombre })
        }
        return nil
    }
}

struct Usuario: Identifiable {
    let id = UUID()
    let correo: String
    let contrasena: String
    let nombre: String
    var acciones: [Accion] = []
    var transacciones: [Transaccion] = []
}

struct Accion: Identifiable {
    let id = UUID()
    let nombre: String
    var porcentaje: Double
    let color: Color
}

struct AccionMercado: Identifiable {
    let id = UUID()
    let nombre: String
    let precio: Double
    let cambio: Double
}

struct Transaccion: Identifiable {
    let id = UUID()
    let descripcion: String
    let fecha: Date
}

// ================================
// LOGIN y REGISTRO
// ================================
struct LoginView: View {
    @EnvironmentObject var appState: AppState
    @State private var correo = ""
    @State private var contrasena = ""
    @State private var mostrarPrincipal = false
    @State private var mensajeError = ""

    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Text("Inicio de Sesión")
                    .font(.largeTitle)
                    .bold()

                TextField("Correo", text: $correo)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .autocapitalization(.none)
                    .keyboardType(.emailAddress)

                SecureField("Contraseña", text: $contrasena)
                    .textFieldStyle(RoundedBorderTextFieldStyle())

                Button("Iniciar Sesión") {
                    if let usuario = appState.usuarios.first(where: { $0.correo == correo && $0.contrasena == contrasena }) {
                        UserDefaults.standard.set(usuario.nombre, forKey: "nombreUsuario")
                        UserDefaults.standard.set(usuario.correo, forKey: "correoActivo")
                        mostrarPrincipal = true
                        mensajeError = ""
                    } else {
                        mensajeError = "Correo o contraseña incorrectos"
                    }
                }
                .buttonStyle(.borderedProminent)
                .tint(.green)

                if !mensajeError.isEmpty {
                    Text(mensajeError)
                        .foregroundColor(.red)
                        .bold()
                }

                NavigationLink(destination: ContentView().environmentObject(appState), isActive: $mostrarPrincipal) {
                    EmptyView()
                }

                NavigationLink(destination: RegistroView().environmentObject(appState)) {
                    Text("Registrar usuario")
                        .foregroundColor(.blue)
                        .underline()
                }
            }
            .padding()
        }
    }
}

struct RegistroView: View {
    @EnvironmentObject var appState: AppState
    @State private var correo = ""
    @State private var contrasena = ""
    @State private var nombre = ""
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        VStack(spacing: 20) {
            Text("Registrar nuevo usuario")
                .font(.title)
                .bold()

            TextField("Nombre", text: $nombre)
                .textFieldStyle(RoundedBorderTextFieldStyle())

            TextField("Correo", text: $correo)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .autocapitalization(.none)
                .keyboardType(.emailAddress)

            SecureField("Contraseña", text: $contrasena)
                .textFieldStyle(RoundedBorderTextFieldStyle())

            Button("Guardar usuario") {
                guard !correo.isEmpty, !contrasena.isEmpty, !nombre.isEmpty else { return }
                if !appState.usuarios.contains(where: { $0.correo.lowercased() == correo.lowercased() }) {
                    // Nuevo usuario sin acciones (portafolio vacío) y sin transacciones
                    let nuevoUsuario = Usuario(correo: correo, contrasena: contrasena, nombre: nombre, acciones: [], transacciones: [])
                    appState.usuarios.append(nuevoUsuario)
                }
                presentationMode.wrappedValue.dismiss()
            }
            .buttonStyle(.borderedProminent)
            .tint(.green)
        }
        .padding()
    }
}

// ================================
// CONTENEDOR PRINCIPAL (menú)
// ================================
struct ContentView: View {
    @EnvironmentObject var appState: AppState
    @State private var selectedScreen: String? = "Inicio"

    var body: some View {
        NavigationView {
            List(selection: $selectedScreen) {
                NavigationLink(destination: InicioView(), tag: "Inicio", selection: $selectedScreen) {
                    Label("Inicio", systemImage: "house.fill")
                }
                NavigationLink(destination: PortafolioView().environmentObject(appState), tag: "Portafolio", selection: $selectedScreen) {
                    Label("Portafolio", systemImage: "briefcase.fill")
                }
                NavigationLink(destination: InvertirView().environmentObject(appState), tag: "Invertir", selection: $selectedScreen) {
                    Label("Invertir", systemImage: "chart.bar.fill")
                }
                NavigationLink(destination: TransaccionesView().environmentObject(appState), tag: "Transacciones", selection: $selectedScreen) {
                    Label("Transacciones", systemImage: "arrow.2.squarepath")
                }
                NavigationLink(destination: ConfiguracionView(), tag: "Configuración", selection: $selectedScreen) {
                    Label("Configuración", systemImage: "gear")
                }
            }
            .listStyle(SidebarListStyle())
            .navigationTitle("Opciones")

            InicioView()
        }
    }
}

// ================================
// VISTA INICIO
// ================================
struct InicioView: View {
    var nombreUsuario: String {
        UserDefaults.standard.string(forKey: "nombreUsuario") ?? "Usuario"
    }

    var body: some View {
        ZStack {
            Color.green.ignoresSafeArea()
            Text("BIENVENIDO \(nombreUsuario.uppercased())!")
                .font(.title)
                .foregroundColor(.white)
                .bold()
        }
    }
}

// ================================
// PORTAFOLIO (muestra porcentajes por acción)
// ================================
struct PortafolioView: View {
    @EnvironmentObject var appState: AppState

    // usuario activo
    var usuarioIndex: Int? { appState.indexUsuarioActivo() }
    var usuarioActual: Usuario? {
        if let idx = usuarioIndex { return appState.usuarios[idx] }
        return nil
    }

    var body: some View {
        VStack(spacing: 16) {
            Text("Portafolio de Acciones")
                .font(.title)
                .bold()
                .padding(.top)

            if let usuario = usuarioActual {
                if usuario.acciones.isEmpty {
                    Text("Aún no tienes acciones en tu portafolio.")
                        .foregroundColor(.gray)
                        .padding()
                } else {
                    // Pie chart
                    PieChartView(acciones: usuario.acciones)
                        .frame(width: 300, height: 300)
                        .padding(.top)

                    // Lista con porcentaje de cada acción
                    List {
                        Section(header: Text("Distribución")) {
                            ForEach(usuario.acciones) { acc in
                                HStack {
                                    VStack(alignment: .leading) {
                                        Text(acc.nombre).font(.headline)
                                        Text("\(acc.porcentaje, specifier: "%.2f")% del portafolio")
                                            .font(.subheadline)
                                            .foregroundColor(.secondary)
                                    }
                                    Spacer()
                                    Circle()
                                        .fill(acc.color)
                                        .frame(width: 20, height: 20)
                                }
                                .padding(.vertical, 6)
                            }
                        }
                    }
                    .listStyle(.plain)
                    .frame(maxHeight: 300)
                }

                // Monto total ficticio (puedes adaptar a valores reales)
                Text("Total invertido (simulado): $10,000.00")
                    .font(.headline)
                    .padding(.bottom)
            } else {
                Text("No hay usuario activo. Inicia sesión.")
                    .foregroundColor(.gray)
            }

            Spacer()
        }
        .padding()
        .onAppear {
            // Asegurar porcentajes normalizados al entrar
            normalizePercentagesForActiveUser()
        }
    }

    // Normaliza porcentajes: si todos 0 -> repartir equitativamente; si suma != 100 -> normalizar proporcionalmente
    func normalizePercentagesForActiveUser() {
        guard let idx = usuarioIndex else { return }
        var acciones = appState.usuarios[idx].acciones
        guard !acciones.isEmpty else { return }

        let suma = acciones.reduce(0) { $0 + $1.porcentaje }
        if suma == 0 {
            let equal = 100.0 / Double(acciones.count)
            for i in acciones.indices { acciones[i].porcentaje = equal }
        } else if suma != 100 {
            for i in acciones.indices {
                let newPct = acciones[i].porcentaje / suma * 100
                acciones[i].porcentaje = newPct
            }
        }
        appState.usuarios[idx].acciones = acciones
    }
}

// ================================
// Pie chart (simple) - usa porcentajes
// ================================
struct PieSliceData: Hashable {
    let index: Int
    let startAngle: Angle
    let endAngle: Angle
    let color: Color
}
struct PieSlice: Shape {
    let startAngle: Angle
    let endAngle: Angle

    func path(in rect: CGRect) -> Path {
        var path = Path()
        let center = CGPoint(x: rect.midX, y: rect.midY)
        let radius = min(rect.width, rect.height) / 2

        path.move(to: center)
        path.addArc(center: center,
                    radius: radius,
                    startAngle: startAngle - Angle(degrees: 90),
                    endAngle: endAngle - Angle(degrees: 90),
                    clockwise: false)
        path.closeSubpath()
        return path
    }
}

struct PieChartView: View {
    let acciones: [Accion]

    var body: some View {
        GeometryReader { geometry in
            let size = min(geometry.size.width, geometry.size.height)

            ZStack {
                ForEach(slices(), id: \.self.index) { slice in
                    PieSlice(startAngle: slice.startAngle, endAngle: slice.endAngle)
                        .fill(slice.color)
                }

                Circle()
                    .fill(Color.white)
                    .frame(width: size * 0.5, height: size * 0.5)

                VStack {
                    Text("Portafolio")
                        .font(.caption)
                        .foregroundColor(.gray)
                }
            }
            .frame(width: size, height: size)
        }
    }

    func slices() -> [PieSliceData] {
        var slices: [PieSliceData] = []
        let total = acciones.reduce(0) { $0 + $1.porcentaje }
        var startAngle = Angle(degrees: 0)

        for (index, accion) in acciones.enumerated() {
            let angle = total > 0 ? Angle(degrees: (accion.porcentaje / total) * 360) : Angle(degrees: 0)
            let endAngle = startAngle + angle
            slices.append(PieSliceData(index: index, startAngle: startAngle, endAngle: endAngle, color: accion.color))
            startAngle = endAngle
        }
        return slices
    }
}

// ================================
// INVERTIR (lista Dow Jones + búsqueda scrollable + comprar)
// ================================
struct InvertirView: View {
    @EnvironmentObject var appState: AppState
    @State private var searchText = ""

    // 30 acciones del Dow Jones (nombres + ejemplo de precio/cambio)
    let mercadoAcciones: [AccionMercado] = [
        AccionMercado(nombre: "Apple", precio: 180.40, cambio: -0.6),
        AccionMercado(nombre: "Microsoft", precio: 310.25, cambio: 2.1),
        AccionMercado(nombre: "Amazon", precio: 135.80, cambio: -1.5),
        AccionMercado(nombre: "American Express", precio: 190.50, cambio: 0.8),
        AccionMercado(nombre: "Amgen", precio: 270.10, cambio: -0.4),
        AccionMercado(nombre: "Boeing", precio: 200.15, cambio: 1.3),
        AccionMercado(nombre: "Caterpillar", precio: 290.25, cambio: -0.5),
        AccionMercado(nombre: "Chevron", precio: 165.75, cambio: 0.9),
        AccionMercado(nombre: "Cisco", precio: 52.30, cambio: 0.2),
        AccionMercado(nombre: "Coca-Cola", precio: 60.80, cambio: 0.3),
        AccionMercado(nombre: "Disney", precio: 92.50, cambio: -1.1),
        AccionMercado(nombre: "Goldman Sachs", precio: 330.40, cambio: 1.6),
        AccionMercado(nombre: "Home Depot", precio: 305.30, cambio: -0.8),
        AccionMercado(nombre: "Honeywell", precio: 190.60, cambio: 0.5),
        AccionMercado(nombre: "IBM", precio: 145.90, cambio: 0.3),
        AccionMercado(nombre: "Intel", precio: 36.20, cambio: -0.7),
        AccionMercado(nombre: "Johnson & Johnson", precio: 155.60, cambio: 0.2),
        AccionMercado(nombre: "JPMorgan Chase", precio: 155.90, cambio: 1.0),
        AccionMercado(nombre: "McDonald’s", precio: 260.80, cambio: -0.3),
        AccionMercado(nombre: "Merck", precio: 112.10, cambio: 0.1),
        AccionMercado(nombre: "Nike", precio: 103.40, cambio: -0.6),
        AccionMercado(nombre: "Procter & Gamble", precio: 145.70, cambio: 0.4),
        AccionMercado(nombre: "Salesforce", precio: 215.50, cambio: 1.2),
        AccionMercado(nombre: "Travelers", precio: 185.40, cambio: -0.2),
        AccionMercado(nombre: "UnitedHealth", precio: 525.90, cambio: 0.8),
        AccionMercado(nombre: "Verizon", precio: 37.80, cambio: -0.1),
        AccionMercado(nombre: "Visa", precio: 245.40, cambio: 0.9),
        AccionMercado(nombre: "Walgreens Boots Alliance", precio: 22.30, cambio: -0.5),
        AccionMercado(nombre: "Walmart", precio: 165.10, cambio: 0.6),
        AccionMercado(nombre: "3M", precio: 92.70, cambio: -0.4)
    ]

    // filtrado en búsqueda
    var filteredAcciones: [AccionMercado] {
        if searchText.isEmpty {
            return mercadoAcciones
        } else {
            return mercadoAcciones.filter { $0.nombre.lowercased().contains(searchText.lowercased()) }
        }
    }

    var body: some View {
        VStack {
            // Searchable lista que se puede scrollear sin problema
            List {
                ForEach(filteredAcciones) { accion in
                    HStack {
                        VStack(alignment: .leading) {
                            Text(accion.nombre)
                                .font(.headline)
                            Text(String(format: "$%.2f", accion.precio))
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                        }
                        Spacer()
                        VStack(alignment: .trailing) {
                            HStack {
                                Image(systemName: accion.cambio >= 0 ? "arrow.up" : "arrow.down")
                                    .foregroundColor(accion.cambio >= 0 ? .green : .red)
                                Text(String(format: "%.2f%%", accion.cambio))
                                    .foregroundColor(accion.cambio >= 0 ? .green : .red)
                                    .font(.subheadline)
                            }
                            // Botón comprar
                            Button("Comprar") {
                                comprar(accionMercado: accion)
                            }
                            .buttonStyle(.bordered)
                            .padding(.top, 6)
                        }
                    }
                    .padding(.vertical, 8)
                }
            }
            .searchable(text: $searchText, placement: .navigationBarDrawer(displayMode: .always), prompt: "Buscar acción...")
            .listStyle(.plain) // scroll limpio
        }
        .navigationTitle("Invertir")
    }

    // Acción de comprar: añade acción al portafolio del usuario activo y crea transacción
    func comprar(accionMercado: AccionMercado) {
        guard let idx = appState.indexUsuarioActivo() else { return }

        // Si ya existe la acción en el portafolio -> no duplicar (podrías cambiar lógica para sumar cantidad)
        if appState.usuarios[idx].acciones.contains(where: { $0.nombre == accionMercado.nombre }) {
            // crear transacción indicando que se intentó sumar
            let t = Transaccion(descripcion: "Compra adicional \(accionMercado.nombre) (ya en portafolio)", fecha: Date())
            appState.usuarios[idx].transacciones.append(t)
        } else {
            // crear nueva Accion en portafolio con porcentaje inicial 0 (luego normalizamos)
            let colores: [Color] = [.blue, .green, .red, .orange, .purple, .pink, .yellow, .cyan]
            let nuevaAccion = Accion(nombre: accionMercado.nombre, porcentaje: 0, color: colores.randomElement() ?? .blue)
            appState.usuarios[idx].acciones.append(nuevaAccion)

            // normalizar porcentajes equitativamente después de la compra (comportamiento simple)
            var acciones = appState.usuarios[idx].acciones
            let equal = 100.0 / Double(acciones.count)
            for i in acciones.indices { acciones[i].porcentaje = equal }
            appState.usuarios[idx].acciones = acciones

            // añadir transacción
            let t = Transaccion(descripcion: "Compra \(accionMercado.nombre) a $\(String(format: "%.2f", accionMercado.precio))", fecha: Date())
            appState.usuarios[idx].transacciones.append(t)
        }
    }
}

// ================================
// TRANSACCIONES (muestra transacciones del usuario activo)
// ================================
struct TransaccionesView: View {
    @EnvironmentObject var appState: AppState

    var transaccionesUsuario: [Transaccion] {
        if let idx = appState.indexUsuarioActivo() {
            return appState.usuarios[idx].transacciones.sorted(by: { $0.fecha > $1.fecha })
        }
        return []
    }

    var body: some View {
        List {
            if transaccionesUsuario.isEmpty {
                Text("No hay transacciones para el usuario activo.")
                    .foregroundColor(.gray)
            } else {
                ForEach(transaccionesUsuario) { t in
                    VStack(alignment: .leading, spacing: 4) {
                        Text(t.descripcion).font(.headline)
                        Text(formatearFecha(t.fecha)).font(.caption).foregroundColor(.secondary)
                    }
                    .padding(.vertical, 4)
                }
            }
        }
        .navigationTitle("Transacciones")
    }

    private func formatearFecha(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
}

// ================================
// CONFIGURACIÓN
// ================================
struct ConfiguracionView: View {
    @State private var notificaciones = true
    @State private var temaOscuro = false

    var body: some View {
        Form {
            Toggle("Notificaciones", isOn: $notificaciones)
            Toggle("Tema oscuro", isOn: $temaOscuro)
            Section(header: Text("Cuenta")) {
                Button(role: .destructive) {
                    UserDefaults.standard.removeObject(forKey: "nombreUsuario")
                    UserDefaults.standard.removeObject(forKey: "correoActivo")
                } label: {
                    Text("Cerrar sesión (limpiar nombre)")
                }
            }
        }
        .navigationTitle("Configuración")
    }
}

