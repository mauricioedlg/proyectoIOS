import SwiftUI

// Este archivo NO debe declarar @main.
// Puedes eliminarlo del proyecto si no lo necesitas.
// Si quieres usar un contenedor, puedes dejar una vista auxiliar:

struct AppContainerView: View {
    var body: some View {
        LoginView()
    }
}

